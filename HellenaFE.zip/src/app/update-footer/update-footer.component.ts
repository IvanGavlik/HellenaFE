import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-footer',
  templateUrl: './update-footer.component.html',
  styleUrls: ['./update-footer.component.css']
})
export class UpdateFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
