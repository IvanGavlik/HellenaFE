import {Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild} from '@angular/core';
import {defaultPage, ItemFeature, SearchItem} from '../search-item';
import {FormControl, FormGroup} from '@angular/forms';
import {debounceTime, Observable, Subscription} from 'rxjs';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatChipInputEvent} from '@angular/material/chips';
import {MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {map, startWith} from 'rxjs/operators';
import {SearchItemService} from '../search-item.service';
import {Entity} from '../../crud/entity';


@Component({
  selector: 'hellena-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css'],
})
export class SearchFormComponent implements OnInit, OnDestroy {


  private searchItem: SearchItem = {} as SearchItem;
  get search(): SearchItem {
      return this.searchItem;
  }
  @Input() set search(searchItem: SearchItem) {
      this.searchItem = searchItem;
      const name = 'name';
      this.searchForm.controls[name].setValue(searchItem?.name);
  }

  @Output()
  searchEvent = new EventEmitter<SearchItem>();

  separatorKeysCodes: number[] = [ENTER, COMMA];
  displayFullSearchForm = true;

  searchForm = new FormGroup(
    {
        name: new FormControl(''),
        priceMIn: new FormControl(0),
        priceMax: new FormControl(0),
        featureControl: new FormControl({}),
        categoryControl: new FormControl([]),
        locationControl: new FormControl([]),
        storeControl: new FormControl([])
    });

  @ViewChild('featureSelect') featureSelect: ElementRef<HTMLSelectElement> = {} as ElementRef;
  features: Pair<ItemFeature, string>[] = [ { id: ItemFeature.CHEAPEST_TODAY, value: 'Najpovoljnije danas' } as Pair<ItemFeature, string> ];
    // category
  @ViewChild('categoryChipper') categoryChipper: ElementRef<HTMLInputElement> = {} as ElementRef;
  category: SelectMultiple<Pair<number, string>> = new SelectMultiple<Pair<number, string>>([], [],
      new Observable<Pair<number, string>[]>(),
      this.searchForm.get('categoryControl') as FormControl);

  // location
  @ViewChild('locationChipper') locationChipper: ElementRef<HTMLInputElement> = {} as ElementRef;
  location: SelectMultiple<Pair<number, string>> = new SelectMultiple<Pair<number, string>>([],[],
      new Observable<Pair<number, string>[]>(),
      this.searchForm.get('locationControl') as FormControl);

  // store
  storeControl = new FormControl('');
  @ViewChild('storeChipper') storeChipper: ElementRef<HTMLInputElement> = {} as ElementRef;
  store: SelectMultiple<Pair<number, string>> = new SelectMultiple<Pair<number, string>>([],[],
            new Observable<Pair<number, string>[]>(),
            this.searchForm.get('storeControl') as FormControl);

  subs: Subscription[] = [];

  constructor(private service: SearchItemService) {}

  ngOnInit(): void {
    this.searchForm.valueChanges
        .pipe(debounceTime(1000))
        .subscribe(value => {
          this.handleSearchFormValueChange(value);
    });

    const initData = new InitDataHelper(this.service);
    const subCategory = initData.allCategory.subscribe(categories => {
        this.category.allItems = categories;
        if (this.search.categoryIds && this.search.categoryIds.length > 0) {
            this.category.items = categories.filter(el => this.search?.categoryIds.find(id => el.id === id) );
        }

    });
    const subLocation = initData.allLocation.subscribe(locations => {
        this.location.allItems = [];
        locations.forEach(l => {
            // only unique
           const inList = this.location.allItems.find(el => el.value === l.value);
           if (inList == null || inList === undefined) {
               this.location.allItems.push(l);
           }
        });
    });
    const subStore = initData.allStore.subscribe(stores => {
        this.store.allItems = stores;
    });
    this.subs.push(subCategory, subLocation, subStore);
  }

  ngOnDestroy(): void {
      this.subs.forEach(el => el?.unsubscribe());
  }

  handleSearchFormValueChange(value: any): void {
    if (value.name) {
      this.displayFullSearchForm = true;
    }

    const search =  {
        priceMIn: value.priceMIn,
        priceMax: value.priceMax,
        categoryIds: (value?.categoryControl as Pair<any, any>[]).map(el => el.id),
        cityIds: (value?.locationControl as Pair<any, any>[]).map(el => el.id),
        storeIds: (value?.storeControl as Pair<any, any>[]).map(el => el.id),
        page : defaultPage()
      } as SearchItem;

    if (value.name) {
        search.name = value.name;
    }
    if (value.featureControl && value.featureControl.length > 0) {
        search.feature = value.featureControl;
    }

    this.searchEvent.emit( search );
  }

  addCategory(event: MatChipInputEvent): void {
      const value = (event.value || '').trim();
      const find = this.category.allItems.find(el => el.value === value);
      if (find) {
          this.category.add(find);
      }
      event.chipInput?.clear();
  }

  removeCategory(el: Pair<number, string>): void {
      this.category.remove(el);
  }

  selectedCategory(event: MatAutocompleteSelectedEvent): void {
      this.category.selected(event.option.value, this.categoryChipper);
  }

  addLocation(event: MatChipInputEvent): void {
      const value = (event.value || '').trim();
      const find = this.location.allItems.find(el => el.value === value);
      if (find) {
          this.location.add(find);
      }
      event.chipInput?.clear();
  }

  removeLocation(el: Pair<number, string>): void {
    this.location.remove(el);
  }

  selectedLocation(event: MatAutocompleteSelectedEvent): void {
    this.location.selected(event.option.value, this.locationChipper);
  }

  addStore(event: MatChipInputEvent): void {
      const value = (event.value || '').trim();
      const find = this.store.allItems.find(el => el.value === value);
      if (find) {
          this.location.add(find);
      }
      event.chipInput?.clear();
  }

  removeStore(el: Pair<number, string>): void {
      this.store.remove(el);
  }

  selectedStore(event: MatAutocompleteSelectedEvent): void {
      this.store.selected(event.option.value, this.storeChipper);
  }

}

class Pair<KEY, VALUE> {
    constructor(public id: KEY, public value: VALUE) {}
}

// TODO ENTER A and stop typing -> change will be triger and value will be A
// maybe some type of validator
// TODO remove duplicates do not send apple, apple on BE
export class SelectMultiple<ELEMENT extends Pair<any, any>> {
    constructor(public items: ELEMENT[],
                public allItems: ELEMENT[],
                public filteredItems: Observable<ELEMENT[]>,
                public formControl: FormControl) {

        this.filteredItems = formControl.valueChanges.pipe(
            startWith(null),
            map((pairList: string | Pair<any, any>) => {
                if (typeof pairList === 'string') {
                    return this.filterByString(pairList);
                }
                return (pairList ? this.filterByPair(pairList) : this.allItems);
            }),
        );

        this.formControl.setValue(this.items);
    }

    add(element: ELEMENT): void {
        if (element && this.allItems.find(el => el === element)) {
            this.items.push(element);
            this.formControl.setValue(this.items);
        }
    }

    remove(element: ELEMENT): void {
        const index = this.items.indexOf(element);
        if (index >= 0) {
            this.items.splice(index, 1);
            this.formControl.setValue(this.items);
        }
    }

    selected(element: ELEMENT, input: ElementRef<HTMLInputElement>): void {
        console.log('selected ', element);
        if (element && this.allItems.find(el => el === element)) {
            this.items.push(element);
            input.nativeElement.value = '';
            this.formControl.setValue(this.items);
        }
    }

    private filterByPair(pairList: Pair<any, any>): ELEMENT[] {
        return this.allItems.filter(el => el === pairList);
    }

    private filterByString(input: string): ELEMENT[] {
        return this.allItems.filter(el => el.value.toString()?.toLowerCase().includes(input?.toLowerCase()));
    }
}


export class InitDataHelper {
    // tslint:disable-next-line:variable-name
    private _allCategory: Observable<Pair<number, string>[]> = new Observable<Pair<number, string>[]>();
    // tslint:disable-next-line:variable-name
    private _allLocation: Observable<Pair<number, string>[]> = new Observable<Pair<number, string>[]>();
    // tslint:disable-next-line:variable-name
    private _allStore: Observable<Pair<number, string>[]> = new Observable<Pair<number, string>[]>();

    constructor(private service: SearchItemService) {
        this._allCategory = this.service.findAllCategory()
            .pipe(
                map(entities => entities.map( el => this.toPair(el as EntityPair))),
            );
        this._allLocation = this.service.findAllCity()
            .pipe(
                map(entities => entities.map( el => this.toPair(el as EntityPair))),
            );
        this._allStore = this.service.findAllStore()
            .pipe(
                map(entities => entities.map( el => this.toPair(el as EntityPair))),
            );
    }

    get allCategory(): Observable<Pair<number, string>[]> {
        return this._allCategory;
    }

    get allLocation(): Observable<Pair<number, string>[]> {
        return this._allLocation;
    }

    get allStore(): Observable<Pair<number, string>[]> {
        return this._allStore;
    }

    private toPair(el1: EntityPair): Pair<number, string> {
        return {
            id: el1.id,
            value: el1.name,
        };
    }
}

class EntityPair extends Entity {
    id = -1;
    name = '';
}

