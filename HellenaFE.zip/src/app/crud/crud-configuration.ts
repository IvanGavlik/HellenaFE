// into decorator
export interface CrudConfiguration {
  findAllEndpoint: string;
}
