export interface CardContainer {
  title: string;
  footer: string;
}
