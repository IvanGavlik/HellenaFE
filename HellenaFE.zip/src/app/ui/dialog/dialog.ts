export interface Dialog {
    title: string;
    content: string;
    onOF: boolean;
}

