export interface InputField {
    type: string;
    label: string;
    placeholder: string;
    initValue?: any;
}
