export interface Card {
  id: number;
  title: string;
  desc: string;
  footer: string;
}
