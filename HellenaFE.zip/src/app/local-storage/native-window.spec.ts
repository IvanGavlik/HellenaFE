import { NativeWindow } from './native-window';

describe('NativeWindow', () => {
  it('should create an instance', () => {
    expect(new NativeWindow()).toBeTruthy();
  });
});
