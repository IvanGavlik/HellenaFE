import { DailyDealConfiguration } from './daily-deal-configuration';

describe('DailyDealConfiguration', () => {
  it('should create an instance', () => {
    expect(new DailyDealConfiguration()).toBeTruthy();
  });
});
