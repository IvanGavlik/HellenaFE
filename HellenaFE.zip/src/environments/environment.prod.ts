export const environment = {
  production: true,
  host: 'https://mysterious-dusk-84277.herokuapp.com',
  version1: '/v1'
};
